# DSA04 - AT3 - Exploratory Data Analysis

Fundamentals of Data Science | Unit 1 - Assessment Tool 3

## Datasets
| # | Dataset | File |
|---|---------|------|
| 1 | Education Analytics | `data/education_analytics.csv` |
| 2 | Healthcare Analytics | `data/healthcare_analytics.csv` |
| 3 | Retail Sales | `data/retail_sales.csv` |
| 4 | Banking Loan Approval | `data/loan_approval.csv` |
| 5 | Agriculture Crop Yield | `data/crop_yield.csv` |

## How to use
1. Open `notebooks/EDA_Assessment.ipynb` in Jupyter/Colab.
2. Run all cells top to bottom.
3. Fill in the **Purpose** and **Observations** markdown cells for each dataset with your own analysis of the output.
4. Write the **Overall Conclusion** at the end.
5. Export the notebook as PDF and save it to `report/EDA_Report.pdf`.
6. Push this repo to GitHub and make sure it's public/accessible before submitting the link.

## Note
This repo is a **starter template only** — code runs and produces charts, but all interpretation
(purpose, observations, conclusion) must be written by the student to meet the assignment's
academic integrity requirement.
